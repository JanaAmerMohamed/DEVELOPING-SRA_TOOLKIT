from libraries import *

def create_footer(root):
    footer = tk.Frame(root, bg='#1F1F1F', height=40)
    footer.pack(side=tk.BOTTOM, fill=tk.X)

    footer_label = tk.Label(footer, text="© 2024 SARS TOOL. All Rights Reserved.", font=("Helvetica", 10), fg="white", bg='#1F1F1F')
    footer_label.pack(pady=10)

def create_toolbar(root, open_intro, open_tool_interface, open_search, open_about):
    # Create a frame for the white toolbar with some gradient effect
    toolbar = tk.Frame(root, bg='#1F1F1F', height=200)
    toolbar.pack(side=tk.TOP, fill=tk.X)

    # Load the transparent PNG logo
    logo_path = "project/images/ddd.png"  # Update with the correct path
    logo_image = Image.open(logo_path)
    logo_image = logo_image.resize((110, 35), Image.Resampling.LANCZOS)
    logo_photo = ImageTk.PhotoImage(logo_image)

    logo_label = tk.Label(toolbar, image=logo_photo, bg='#1F1F1F')
    logo_label.pack(side=tk.LEFT, padx=30)

    # Keep a reference to the image to avoid garbage collection
    logo_label.image = logo_photo

    # Hover effect for toolbar buttons
    def on_enter_toolbar(e, button):
        button['bg'] = '#3E3E3E'

    def on_leave_toolbar(e, button):
        button['bg'] = '#1F1F1F'

    # Add navigation buttons to the toolbar with hover effects
    nav_buttons = {
        "Home": open_intro,
        "Advanced Search": open_tool_interface,
        "Quick Search": open_search,
        "About": open_about,
    }

    for button_text, button_command in nav_buttons.items():
        nav_button = tk.Button(toolbar, text=button_text, font=("Helvetica", 13), bg="#1F1F1F", fg="white", borderwidth=0, command=button_command)
        nav_button.pack(side=tk.LEFT, padx=20)
        nav_button.bind("<Enter>", lambda f, b=nav_button: on_enter_toolbar(f, b))
        nav_button.bind("<Leave>", lambda f, b=nav_button: on_leave_toolbar(f, b))


def download_fastq(run_acc, output_directory):
    if output_directory:
        command = f"fastq-dump --outdir \"{output_directory}\" {run_acc}"
        try:
            subprocess.run(command, check=True, shell=True)
        except subprocess.CalledProcessError:
            show_message("Error", f"Error downloading FASTQ file for {run_acc}")
    else:
        show_message("Cancelled", "Download cancelled by user.")  

def show_message(title, message):
    tk.messagebox.showinfo(title, message)     

    