from libraries import *

root = tk.Tk()

root.title("Learn More")
root.geometry("1000x800")
root.configure(bg='#121212')  # Set the background to a very dark gray

# Function to open the tool interface (assuming it's defined in another file/module)
def open_tool_interface():
    root.destroy()  # Close the current window
    import advanced_search  # Replace with your actual module if it's in another file

# Function to open the introduction page
def open_Intro():
    root.destroy()  # Close the current window
    import  intro  # Replace with your actual module if it's in another file

# Function to open the About page
def open_about():
    root.destroy()  # Close the current window
    import  about  # Replace with your actual module if it's in another file

# Function to open the Quick Search page
def open_search():
    root.destroy()  # Close the current window
    import  quick_search  # Replace with your actual module if it's in another file

def learn_more():
    root.destroy()  # Close the current window
    import  learn_more  # Replace with your actual module if it's in another 


class VideoPlayer:
    def __init__(self, window, video_source):
        self.window = window
        self.window.title("Video Player")

        # Create a frame for the video card
        self.card_frame = tk.Frame(window, width=1000, height=600, bg='#2C2C2C')
        self.card_frame.pack_propagate(False)  # Prevent the frame from resizing
        self.card_frame.pack()

        # Create a canvas for video display
        self.canvas = tk.Canvas(self.card_frame, width=990, height=500)
        self.canvas.grid(row=0, column=0, columnspan=2, padx=5, pady=5)  # Place canvas in grid

        # Create a progress bar
        self.progress_bar = ttk.Progressbar(self.card_frame, orient="horizontal", length=900, mode="determinate")
        self.progress_bar.grid(row=1, column=0, padx=5, pady=5, sticky="ew")  # Place progress bar in grid

        # Create play/pause button
        self.play_pause_button = tk.Button(self.card_frame, text="Play", command=self.toggle_play_pause,
                                           bg="#4CAF50", fg="white", font=("Helvetica", 10, "bold"),
                                           width=5, height=1, relief="raised")
        self.play_pause_button.grid(row=1, column=1, padx=5, pady=5)  # Place button beside progress bar

        # Create an indicator label
        self.indicator = tk.Label(self.card_frame, text="Status: Paused", bg=self.card_frame.cget('background'),
                                  fg="white", font=("Helvetica", 10, "bold"))
        self.indicator.grid(row=2, column=0, padx=5, pady=5)  # Place indicator in grid

        # Create a time display label
        self.time_display = tk.Label(self.card_frame, text="Time: 00:00", bg=self.card_frame.cget('background'),
                                     fg="white", font=("Helvetica", 10, "bold"))
        self.time_display.grid(row=2, column=1, padx=5, pady=5)  # Place time display beside indicator

        # Open the video source
        self.vid = cv2.VideoCapture(video_source)
        if not self.vid.isOpened():
            show_message("Alarm","Error: Couldn't open video file.")
            return

        # Get total video duration
        self.total_frames = int(self.vid.get(cv2.CAP_PROP_FRAME_COUNT))
        self.frame_rate = self.vid.get(cv2.CAP_PROP_FPS)

        # Variable to control video play/pause state
        self.playing = False

        # Start the video update loop
        self.update()

    def update(self):
        if self.playing:
            ret, frame = self.vid.read()
            if ret:
            # Convert the frame to a format Tkinter can handle
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            
            # Rescale the frame to fit within the canvas dimensions
                frame = cv2.resize(frame, (self.canvas.winfo_width(), self.canvas.winfo_height()))
            
                self.photo = ImageTk.PhotoImage(image=Image.fromarray(frame))

            # Clear the canvas and display the frame
                self.canvas.delete("all")
                self.canvas.create_image(0, 0, image=self.photo, anchor=tk.NW)

            # Update time display
                current_time = self.vid.get(cv2.CAP_PROP_POS_MSEC) / 1000
                minutes = int(current_time // 60)
                seconds = int(current_time % 60)
                self.time_display.config(text=f"Time: {minutes:02}:{seconds:02}")

            # Update progress bar
                current_frame = int(self.vid.get(cv2.CAP_PROP_POS_FRAMES))
                progress = (current_frame / self.total_frames) * 100
                self.progress_bar['value'] = progress

        # Schedule the next update
            self.window.after(int(1000 / self.frame_rate), self.update)  # Adjust delay for video frame rate
 # Adjust delay for video frame rate

    def toggle_play_pause(self):
        if self.playing:
            self.playing = False
            self.indicator.config(text="Status: Paused")
            self.play_pause_button.config(text="Play")
        else:
            self.playing = True
            self.indicator.config(text="Status: Playing")
            self.play_pause_button.config(text="Pause")
            self.update()  # Start updating video frames

    def __del__(self):
        if self.vid.isOpened():
            self.vid.release()
            
create_toolbar(root, open_Intro, open_tool_interface, open_search, open_about)
create_footer(root)

player = VideoPlayer(root, 'project\Video\marc_video.mp4')

# Text Frame
text_frame = tk.Frame(root, bg='#2C2C2C')
text_frame.pack(side=tk.TOP, padx=20, pady=30)  # Add padding around the frame
# Create a centered card layout for the main content
def create_page1(parent, navigation):
    """Create the content for About Page 1."""
    frame = tk.Frame(parent, bg='#2C2C2C')
    label = tk.Label(frame, text="OverView", bg='#2C2C2C', fg='white', font=('Helvetica', 26, 'bold'))
    label.pack(pady=10, padx=10)

    content_text = (
        "The SRA TOOL is designed to help users efficiently search and retrieve relevant BioProjects and BioSamples from NCBI’s Sequence Read Archive (SRA) using the PICO principles. This tool is especially useful for researchers and bioinformaticians who need to access and analyze high-throughput sequencing data."
    )
    content_label = tk.Label(frame, text=content_text, bg='#2C2C2C', fg='white', font=('Helvetica', 16),
                             wraplength=800, justify='left')
    content_label.pack(pady=10, padx=20, fill='both', expand=True)

    # Navigation buttons
    nav_frame = tk.Frame(frame, bg='#2C2C2C')
    nav_frame.pack(side=tk.BOTTOM, pady=20)

    if navigation.get('next'):
        next_button = tk.Button(nav_frame, text="Next", font=("Arial", 12), bg="#009688", fg="white", borderwidth=0,
                                command=navigation['next'])
        next_button.pack(side=tk.LEFT, padx=10)
    
    return frame

def create_page2(parent, navigation):
    """Create the content for About Page 2."""
    frame = tk.Frame(parent, bg='#2C2C2C')
    label = tk.Label(frame, text="Search Criteria", bg='#2C2C2C', fg='white', font=('Helvetica', 26, 'bold'))
    label.pack(pady=10, padx=10)

    content_text = (
        "Population (P): Define the target population for your study.\nInterventions (I): Specify the interventions or treatments of interest. \nComparison (C): Outline the comparison groups or conditions. \nOutcomes (O): Identify the desired outcomes or results."
    )
    content_label = tk.Label(frame, text=content_text, bg='#2C2C2C', fg='white', font=('Helvetica', 16),
                             wraplength=800, justify='left')
    content_label.pack(pady=20, padx=20, fill='both', expand=True)

    # Navigation buttons
    nav_frame = tk.Frame(frame, bg='#2C2C2C')
    nav_frame.pack(side=tk.BOTTOM, pady=20)

    prev_button = tk.Button(nav_frame, text="Previous", font=("Arial", 12), bg="#E64A19", fg="white", borderwidth=0,
                            command=navigation['prev'])
    prev_button.pack(side=tk.LEFT, padx=10)
    
    if navigation.get('next'):
        next_button = tk.Button(nav_frame, text="Next", font=("Arial", 12), bg="#009688", fg="white", borderwidth=0,
                                command=navigation['next'])
        next_button.pack(side=tk.LEFT, padx=10)
    
    return frame
def create_page3(parent, navigation):
    """Create the content for About Page 3."""
    frame = tk.Frame(parent, bg='#2C2C2C')
    label = tk.Label(frame, text="Search and Retrieval", bg='#2C2C2C', fg='white', font=('Helvetica', 26, 'bold'))
    label.pack(pady=10, padx=10)

    content_text = (
        "Input parameters based on the PICO framework to search for relevant BioProjects.\nRetrieve a list of BioProjects based on your criteria."
    )
    content_label = tk.Label(frame, text=content_text, bg='#2C2C2C', fg='white', font=('Helvetica', 16),
                             wraplength=800, justify='left')
    content_label.pack(pady=20, padx=20, fill='both', expand=True)

    # Navigation buttons
    nav_frame = tk.Frame(frame, bg='#2C2C2C')
    nav_frame.pack(side=tk.BOTTOM, pady=20)

    prev_button = tk.Button(nav_frame, text="Previous", font=("Arial", 12), bg="#E64A19", fg="white", borderwidth=0,
                            command=navigation['prev'])
    prev_button.pack(side=tk.LEFT, padx=10)
    
    if navigation.get('next'):
        next_button = tk.Button(nav_frame, text="Next", font=("Arial", 12), bg="#009688", fg="white", borderwidth=0,
                                command=navigation['next'])
        next_button.pack(side=tk.LEFT, padx=10)
    
    return frame

def create_page4(parent, navigation):
    """Create the content for About Page 4."""
    frame = tk.Frame(parent, bg='#2C2C2C')
    label = tk.Label(frame, text="BioProject Selection", bg='#2C2C2C', fg='white', font=('Helvetica', 26, 'bold'))
    label.pack(pady=10, padx=10)

    content_text = (
        "Select a BioProject from the search results. \n you can copy the BioProject ID by right click on it. \n View detailed information about the selected BioProject, including its title, description, and the number of associated BioSamples."
    )
    content_label = tk.Label(frame, text=content_text, bg='#2C2C2C', fg='white', font=('Helvetica', 16),
                             wraplength=800, justify='left')
    content_label.pack(pady=20, padx=20, fill='both', expand=True)

    # Navigation buttons
    nav_frame = tk.Frame(frame, bg='#2C2C2C')
    nav_frame.pack(side=tk.BOTTOM, pady=20)

    prev_button = tk.Button(nav_frame, text="Previous", font=("Arial", 12), bg="#E64A19", fg="white", borderwidth=0,
                            command=navigation['prev'])
    prev_button.pack(side=tk.LEFT, padx=10)
    
    if navigation.get('next'):
        next_button = tk.Button(nav_frame, text="Next", font=("Arial", 12), bg="#009688", fg="white", borderwidth=0,
                                command=navigation['next'])
        next_button.pack(side=tk.LEFT, padx=10)
    
    return frame

def create_page5(parent, navigation):
    """Create the content for About Page 4."""
    frame = tk.Frame(parent, bg='#2C2C2C')
    label = tk.Label(frame, text="BioSample Details", bg='#2C2C2C', fg='white', font=('Helvetica', 26, 'bold'))
    label.pack(pady=10, padx=10)

    content_text = (
        "Click on a BioProject to display all related BioSamples.\nEach BioSample includes links to its NCBI page and the SRA for verification."
    )
    content_label = tk.Label(frame, text=content_text, bg='#2C2C2C', fg='white', font=('Helvetica', 16),
                             wraplength=800, justify='left')
    content_label.pack(pady=20, padx=20, fill='both', expand=True)

    # Navigation buttons
    nav_frame = tk.Frame(frame, bg='#2C2C2C')
    nav_frame.pack(side=tk.BOTTOM, pady=20)

    prev_button = tk.Button(nav_frame, text="Previous", font=("Arial", 12), bg="#E64A19", fg="white", borderwidth=0,
                            command=navigation['prev'])
    prev_button.pack(side=tk.LEFT, padx=10)
    
    if navigation.get('next'):
        next_button = tk.Button(nav_frame, text="Next", font=("Arial", 12), bg="#009688", fg="white", borderwidth=0,
                                command=navigation['next'])
        next_button.pack(side=tk.LEFT, padx=10)
    
    return frame

def create_page6(parent, navigation):
    """Create the content for About Page 4."""
    frame = tk.Frame(parent, bg='#2C2C2C')
    label = tk.Label(frame, text="FASTQ File Download", bg='#2C2C2C', fg='white', font=('Helvetica', 26, 'bold'))
    label.pack(pady=10, padx=10)

    content_text = (
        "Select BioSamples and download their FASTQ files, with the option to choose the download path for the FASTQ files."
    )
    content_label = tk.Label(frame, text=content_text, bg='#2C2C2C', fg='white', font=('Helvetica', 16),
                             wraplength=800, justify='left')
    content_label.pack(pady=20, padx=20, fill='both', expand=True)

    # Navigation buttons
    nav_frame = tk.Frame(frame, bg='#2C2C2C')
    nav_frame.pack(side=tk.BOTTOM, pady=20)

    prev_button = tk.Button(nav_frame, text="Previous", font=("Arial", 12), bg="#E64A19", fg="white", borderwidth=0,
                            command=navigation['prev'])
    prev_button.pack(side=tk.LEFT, padx=10)
    
    if navigation.get('next'):
        next_button = tk.Button(nav_frame, text="Next", font=("Arial", 12), bg="#009688", fg="white", borderwidth=0,
                                command=navigation['next'])
        next_button.pack(side=tk.LEFT, padx=10)
    
    return frame

def show_about_page(page_number):
    """Show a specific About page."""
    global current_page_frame
    if current_page_frame:
        current_page_frame.pack_forget()
    
    if page_number == 1:
        current_page_frame = create_page1(text_frame, {'next': lambda: show_about_page(2)})
    elif page_number == 2:
        current_page_frame = create_page2(text_frame, {'prev': lambda: show_about_page(1), 'next': lambda: show_about_page(3)})
    elif page_number == 3:
        current_page_frame = create_page3(text_frame, {'prev': lambda: show_about_page(2), 'next': lambda: show_about_page(4)})
    elif page_number == 4:
        current_page_frame = create_page4(text_frame, {'prev': lambda: show_about_page(3), 'next': lambda: show_about_page(5)})
    elif page_number == 5:
        current_page_frame = create_page5(text_frame, {'prev': lambda: show_about_page(4), 'next': lambda: show_about_page(6)})
                
    elif page_number == 6:
        current_page_frame = create_page6(text_frame, {'prev': lambda: show_about_page(5)})
    
    current_page_frame.pack(fill='both', expand=True)


current_page_frame = None
show_about_page(1)
# Run the Tkinter event loop
root.mainloop()