from libraries import *

# Function to open the tool interface (assuming it's defined in another file/module)
def open_tool_interface():
    root.destroy()  # Close the current window
    import advanced_search  # Replace with your actual module if it's in another file

# Function to open the introduction page
def open_Intro():
    root.destroy()  # Close the current window
    import  intro  # Replace with your actual module if it's in another file

# Function to open the About page
def open_about():
    root.destroy()  # Close the current window
    import  about  # Replace with your actual module if it's in another file

# Function to open the Quick Search page
def open_search():
    root.destroy()  # Close the current window
    import  quick_search  # Replace with your actual module if it's in another file

def learn_more():
    root.destroy()  # Close the current window
    import  learn_more  # Replace with your actual module if it's in another 

# Initialize the main window
root = tk.Tk()
root.title("Marc")
root.geometry("1000x800")
root.configure(bg='#121212')  # Set the background to a very dark gray

create_toolbar(root, open_Intro, open_tool_interface, open_search, open_about)

# Create a centered card layout for the main content
card_frame = tk.Frame(root, bg='#2C2C2C', width=700, height=500, bd=0, relief=tk.RIDGE)
card_frame.pack(pady=50, expand=True)

# Add some padding inside the card
card_content = tk.Frame(card_frame, bg='#2C2C2C', padx=40, pady=40)
card_content.pack(expand=True)

# Load and display the custom image with white background
image_path = "project\images\Free_Vector___Flat_illustration_biotechnology_concept-removebg.png"
image = Image.open(image_path)
image = image.resize((250, 250), Image.Resampling.LANCZOS)
photo = ImageTk.PhotoImage(image)

# Display the image inside the card
image_label = tk.Label(card_content, image=photo, bg='#2C2C2C')
image_label.grid(row=0, column=0, rowspan=3, padx=20, pady=10, sticky="w")

# Add text next to the image in the card
text_frame = tk.Frame(card_content, bg='#2C2C2C')
text_frame.grid(row=0, column=1, padx=30, pady=10, sticky="nsew")

# Add the title and description inside the card
title_label = tk.Label(text_frame, text='       SARS TOOL  ', font=("Helvetica", 30, "bold", "italic"), fg="white", bg='#2C2C2C')
title_label.pack(anchor="w")

description = """  Our innovative tool is designed to help you
with a range of features to enhance your workflow"""
description_label = tk.Label(text_frame, text=description, font=("Helvetica", 14), fg="white", bg='#2C2C2C', justify="center")
description_label.pack(anchor="w", pady=(30, 20))

# Add buttons with different color scheme and hover effects
def on_enter_button(e, button):
    button['bg'] = '#00796B'  # Change the background color on hover

def on_leave_button(e, button):
    button['bg'] = '#009688'  # Revert the background color on leave

get_started_button = tk.Button(text_frame, text="Get Started", font=("Helvetica", 16), bg="#009688", fg="white", command=open_tool_interface, borderwidth=0, relief=tk.FLAT)
get_started_button.pack(side=tk.LEFT, padx=50, pady=10)
get_started_button.bind("<Enter>", lambda e: on_enter_button(e, get_started_button))
get_started_button.bind("<Leave>", lambda e: on_leave_button(e, get_started_button))

def on_enter_learn(e):
    learn_button['bg'] = '#D84315'

def on_leave_learn(e):
    learn_button['bg'] = '#E64A19'

learn_button = tk.Button(text_frame, text="Learn More", font=("Helvetica", 16), bg="#E64A19", fg="white",command= learn_more, borderwidth=0, relief=tk.FLAT)
learn_button.pack(side=tk.LEFT, padx=20, pady=5)
learn_button.bind("<Enter>", on_enter_learn)
learn_button.bind("<Leave>", on_leave_learn)

create_footer(root)

# Run the Tkinter event loop
root.mainloop()
