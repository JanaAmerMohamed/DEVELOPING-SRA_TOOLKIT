from libraries import *

def open_tool_interface():
    root.destroy()  # Close the current window
    import advanced_search  # Replace with your actual module if it's in another file

def open_intro():
    root.destroy()  # Close the current window
    import intro  # Replace with your actual module if it's in another file

def open_about():
    root.destroy()  # Close the current window
    import  about  # Replace with your actual module if it's in another file

def open_search():
    root.destroy()  # Close the current window
    import  quick_search  # Replace with your actual module if it's in another file

def learn_more():
    root.destroy()  # Close the current window
    import  learn_more  # Replace with your actual module if it's in another 


def search_projects():
    # Clear previous search results from the table
    for item in table.get_children():
        table.delete(item)
    
    progress_var.set(0)  # Reset progress bar at the beginning of the search
    root.update_idletasks()

    selected_population = population_var.get()
    selected_intervention = intervention_var.get()
    selected_comparison = comparison_var.get()
    selected_outcome = outcome_var.get()

    url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
    term = f"{selected_population} AND {selected_intervention} AND {selected_comparison} AND {selected_outcome}"
    params = {
        'db': 'bioproject',
        'term': term,
        'retmode': 'json',
        'retmax': 10
    }

    response = requests.get(url, params=params)

    if response.status_code == 200:
        data = response.json()
        project_ids = data.get('esearchresult', {}).get('idlist', [])
        if project_ids:
            fetch_next_project(project_ids)
        else:
            show_message("No Results", "No projects found for the given search criteria.")
    else:
        show_message("Error", "Error fetching data from NCBI. Please try again later.")

def fetch_next_project(project_ids):
    total_projects = len(project_ids)
    if project_ids:
        project_id = project_ids.pop(0)
        project_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi"
        project_params = {
            'db': 'bioproject',
            'id': project_id,
            'retmode': 'xml'
        }
        project_response = requests.get(project_url, params=project_params)
        if project_response.status_code == 200:
            project_xml = ET.fromstring(project_response.content)
            docsum = project_xml.find('.//DocumentSummary')

            if docsum is not None:
                title = docsum.find('.//Project_Title').text if docsum.find('.//Project_Title') is not None else "No Title"
                description = docsum.find('.//Project_Description').text if docsum.find('.//Project_Description') is not None else "No Description"
                name = docsum.find('.//Project_Name').text if docsum.find('.//Project_Name') is not None else "No Project Name"
                samples_count = get_biosample_count(project_id)
            else:
                title, description, name, samples_count = "No Title Found", "No Description Found", "No Project Name Found", "No Samples Found"

            table.insert("", "end", values=(project_id, name, title, description, samples_count))

            # Calculate and update the progress
            completed = total_projects - len(project_ids)
            progress_var.set((completed / total_projects) * 100)
            root.update_idletasks()

            # Fetch the next project after a short delay
            root.after(500, fetch_next_project, project_ids)
        else:
            table.insert("", "end", values=(project_id, "Error fetching details", "N/A", "N/A", "N/A"))
            root.after(500, fetch_next_project, project_ids)
    else:
        progress_var.set(100)  # Set progress bar to 100% on completion
        root.update_idletasks()
        # Corrected the function call with both title and message arguments
        show_message("Completed", "All projects fetched.")


def get_biosample_count(project_id):
    biosample_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/elink.fcgi"
    biosample_params = {
        'dbfrom': 'bioproject',
        'db': 'biosample',
        'linkname': 'bioproject_biosample',
        'id': project_id,
        'retmode': 'xml'
    }

    biosample_response = requests.get(biosample_url, params=biosample_params)
    if biosample_response.status_code == 200:
        biosample_xml = ET.fromstring(biosample_response.content)
        linkset = biosample_xml.find('.//LinkSetDb')

        if linkset:
            return len(linkset.findall('.//Link'))
    return "No Samples Found"

def display_text_in_popup(title, text):
    popup = tk.Toplevel(root)
    popup.title(title)

    text_area = tk.Text(popup, wrap=tk.WORD, width=80, height=20)
    text_area.insert(tk.END, text)
    text_area.config(state=tk.DISABLED)
    text_area.pack(expand=True, fill='both', padx=10, pady=10)

    close_button = ttk.Button(popup, text="Close", command=popup.destroy)
    close_button.pack(pady=10)

def fetch_biosamples(project_id):
    def _fetch():
        biosample_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/elink.fcgi"
        biosample_params = {
            'dbfrom': 'bioproject',
            'db': 'biosample',
            'linkname': 'bioproject_biosample',
            'id': project_id,
            'retmode': 'xml'
        }

        # Fetch the biosample data
        biosample_response = requests.get(biosample_url, params=biosample_params)
        if biosample_response.status_code == 200:
            biosample_xml = ET.fromstring(biosample_response.content)
            linkset = biosample_xml.find('.//LinkSetDb')

            if linkset:
                total_links = len(linkset.findall('.//Link'))
                row_idx = 2  # Start from the second row after the headers

                for index, link in enumerate(linkset.findall('.//Link')):
                    biosample_id = link.find('Id').text
                    biosample_link = f"https://www.ncbi.nlm.nih.gov/biosample/{biosample_id}"

                    var = tk.BooleanVar()
                    checkbox = tk.Checkbutton(table_frame, text=f"{biosample_id}", variable=var, bg='#121212', fg='white', selectcolor='#1F1F1F', font=15)
                    checkbox.grid(column=0, row=row_idx, padx=10, pady=5)
                    
                    biosample_link_label = tk.Label(table_frame, text="Open BioSample Link", foreground="#3776ab", cursor="hand2", bg='#121212', font=15)
                    biosample_link_label.grid(column=1, row=row_idx, padx=10, pady=5)
                    biosample_link_label.bind("<Button-1>", lambda e, url=biosample_link: open_url(url))

                    sra_run_id = get_sra_run_id(biosample_id)
                    if sra_run_id:
                        sra_link_label = tk.Label(table_frame, text="Open SRA Link", foreground="#3776ab", cursor="hand2", bg='#121212', font=15)
                        sra_link_label.grid(column=2, row=row_idx, padx=10, pady=5)
                        sra_link_label.bind("<Button-1>", lambda e, id=sra_run_id: open_url(f"https://www.ncbi.nlm.nih.gov/sra/{id}"))

                    checkbox_vars.append(var)
                    selected_biosamples.append(biosample_id)

                    row_idx += 1

                    # Update progress bar
                    progress_var.set((index + 1) / total_links * 100)
                    progressbar.update_idletasks()

                download_button.grid(column=0, row=row_idx, columnspan=3, pady=10)

                canvas.update_idletasks()
                canvas.config(scrollregion=canvas.bbox("all"))

            else:
                display_text_in_popup("BioSamples", "No BioSamples found.")
        else:
            display_text_in_popup("BioSamples", "Error fetching BioSamples.")

        # Hide the progress bar once the fetching is complete
        

    biosample_window = tk.Toplevel(root)
    biosample_window.title(f"BioSamples and SRA for Project {project_id}")
    biosample_window.configure(bg='#121212')
    biosample_window.geometry("1000x800")  # 800x600 is the size, 100+100 is the position
    
    create_toolbar(biosample_window, open_intro, open_tool_interface, open_search, open_about)
   
    # Progress Bar
    progress_var = tk.DoubleVar()
    progressbar = ttk.Progressbar(biosample_window, variable=progress_var, maximum=100, mode='determinate', length=900)
    progressbar.pack(pady=10)  # Use pack to ensure it is at the top of the toolbar


    create_footer(biosample_window)

    control_frame = tk.Frame(biosample_window, bg='#121212')
    control_frame.pack(anchor="center", pady=10, expand=False)

    # Canvas and Scrollable Frame
    canvas = tk.Canvas(biosample_window, bg="#121212", width=800, height=800)
    canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    scrollbar = ttk.Scrollbar(biosample_window, orient="vertical", command=canvas.yview)
    scrollable_frame = ttk.Frame(biosample_window, padding="15", style="TFrame")

    scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    table_frame = tk.Frame(canvas, bg='#121212')
   
    canvas.create_window((0, 0), window=table_frame, anchor="nw")

    style = ttk.Style()
    style.configure('TLabel', background='#1F1F1F', foreground='white')

    # Select All Checkbox
    select_all_var = tk.BooleanVar()
    select_all_checkbox = tk.Checkbutton(control_frame, text="Select All", variable=select_all_var,font=15 ,bg='#121212', fg='white', selectcolor='#1F1F1F', command=lambda: select_all_checkboxes(select_all_var, checkbox_vars))
    select_all_checkbox.grid(column=0, row=0, padx=10, pady=10, sticky='w')

    # Download Button
    download_button = tk.Button(control_frame, text="Download Selected FASTQ Files", 
                            font=("Helvetica", 15), bg="#E64A19", fg="white", 
                            borderwidth=0, relief=tk.FLAT, 
                            command=lambda: download_all(checkbox_vars, selected_biosamples))
    download_button.grid(column=1, row=0, padx=10, pady=10, sticky='w')
    def on_enter_buttom(e):
        download_button['bg'] = '#D84315'

    def on_leave_buttom(e):
        download_button['bg'] = '#E64A19'
# Bind the hover effects to the download button
    download_button.bind("<Enter>", on_enter_buttom)
    download_button.bind("<Leave>",on_leave_buttom )

    # Table Headers inside the scrollable canvas
    headers = ["BioSample ID", "BioSample Link", "SRA Link"]
    for col, header in enumerate(headers):
        header_label = tk.Label(table_frame, text=header, bg='#121212', fg='white', font=("Helvetica", 15, 'bold'))
        header_label.grid(row=1, column=col, padx=10, pady=5)
    
    # Start the fetch process in a separate thread to keep the UI responsive
    threading.Thread(target=_fetch, daemon=True).start()


checkbox_vars = []
selected_biosamples = []

def select_all_checkboxes(select_all_var, checkbox_vars):
    for var in checkbox_vars:
        var.set(select_all_var.get())


def format_time(seconds):
    """Format time in HH:MM:SS"""
    hours, remainder = divmod(int(seconds), 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{hours:02}:{minutes:02}:{seconds:02}"

def download_all(checkbox_vars, selected_biosamples):
    selected_ids = [biosample_id for var, biosample_id in zip(checkbox_vars, selected_biosamples) if var.get()]
    download_acc_list = []

    if selected_ids:
        output_directory = filedialog.askdirectory(title="Select Download Directory for All FASTQ Files")
        if not output_directory:
            show_message("Cancelled", "Download cancelled by user.")
            return

        for biosample_id in selected_ids:
            sra_run_id = get_sra_run_id(biosample_id)
            if sra_run_id:
                view_sra_xml_all(sra_run_id, None, None, download_acc_list)

        if download_acc_list:
            loading_window = tk.Toplevel()
            loading_window.title("Downloading")
            
            loading_label = tk.Label(loading_window, text="Downloading FASTQ files, please wait...")
            loading_label.pack(pady=10)

            progress_bar = ttk.Progressbar(loading_window, orient="horizontal", length=280, mode="determinate")
            progress_bar.pack(pady=10)

            time_remaining_label = tk.Label(loading_window, text="Estimated time remaining: Calculating...")
            time_remaining_label.pack(pady=10)
            
            loading_window.geometry("350x150")

            # Use threading to handle the download process
            download_thread = threading.Thread(target=download_files, args=(download_acc_list, output_directory, loading_window, progress_bar, time_remaining_label))
            download_thread.start()
        else:
            show_message("Download", "No FASTQ files found to download.")
    else:
        show_message("Download", "No BioSamples selected for download.")

def download_files(download_acc_list, output_directory, loading_window, progress_bar, time_remaining_label):
    total_files = len(download_acc_list)
    start_time = time.time()
    for i, run_acc in enumerate(download_acc_list):
        download_fastq(run_acc, output_directory)
        progress = (i + 1) / total_files * 100
        progress_bar['value'] = progress
        loading_window.update_idletasks()
        
        elapsed_time = time.time() - start_time
        estimated_time = (elapsed_time / (i + 1)) * (total_files - (i + 1))
        time_remaining_label.config(text=f"Estimated time remaining: {format_time(estimated_time)}")
    
    loading_window.destroy()
    show_message("Download Complete", f"All selected FASTQ files have been downloaded to {output_directory}.")


def view_sra_xml_all(run_id, parent_window, row_idx, download_acc_list):
    sra_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi"
    sra_params = {
        'db': 'sra',
        'id': run_id,
        'retmode': 'xml'
    }

    sra_response = requests.get(sra_url, params=sra_params)
    if sra_response.status_code == 200:
        try:
            sra_xml = ET.fromstring(sra_response.content)
            run_element = sra_xml.find(".//Item[@Name='Runs']")
            if run_element is not None:
                run_element_text = run_element.text
                if run_element_text:
                    run_xml = ET.fromstring(run_element_text)
                    run_acc = run_xml.attrib.get('acc')
                    if run_acc:
                        download_acc_list.append(run_acc)
                    else:
                        show_message("Alarm","Error: 'acc' attribute not found.")
                else:
                    show_message("Alarm","Error: No text content in 'Runs' element.")
            else:
                show_message("Alarm","Error: 'Runs' element not found.")
        except ET.ParseError:
            show_message("Alarm","Error parsing the XML content.")
    else:
        show_message("Alarm",f"Error fetching XML for SRA ID {run_id}")


def get_sra_run_id(biosample_id):
    sra_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/elink.fcgi"
    sra_params = {
        'dbfrom': 'biosample',
        'db': 'sra',
        'linkname': 'biosample_sra',
        'id': biosample_id,
        'retmode': 'xml'
    }

    sra_response = requests.get(sra_url, params=sra_params)
    if sra_response.status_code == 200:
        sra_xml = ET.fromstring(sra_response.content)
        linkset = sra_xml.find('.//LinkSetDb')

        if linkset:
            sra_run_id = linkset.find('.//Link/Id')
            return sra_run_id.text if sra_run_id is not None else None
    return None

def view_sra_xml(run_id, parent_window, row_idx):
    sra_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi"
    sra_params = {
        'db': 'sra',
        'id': run_id,
        'retmode': 'xml'
    }

    sra_response = requests.get(sra_url, params=sra_params)
    if sra_response.status_code == 200:
        try:
            sra_xml = ET.fromstring(sra_response.content)
            run_element = sra_xml.find(".//Item[@Name='Runs']")
            if run_element is not None:
                run_element_text = run_element.text
                if run_element_text:
                    run_xml = ET.fromstring(run_element_text)
                    run_acc = run_xml.attrib.get('acc')
                    if run_acc:
                        # Directly add the "Download FASTQ" button beside the "Open SRA Link" label
                        download_button = ttk.Button(parent_window, text="Download FASTQ", command=lambda: download_fastq(run_acc))
                        download_button.grid(column=3, row=row_idx, padx=10, pady=5)
                    else:
                        show_message("Alarm","Error: 'acc' attribute not found.")
                else:
                    show_message("Alarm","Error: No text content in 'Runs' element.")
            else:
                show_message("Alarm","Error: 'Runs' element not found.")
        except ET.ParseError:
            show_message("Alarm","Error parsing the XML content.")
    else:
        show_message("Alarm",f"Error fetching XML for SRA ID {run_id}")

def open_url(url):
    webbrowser.open(url)

def on_tree_click(event):
    region = table.identify("region", event.x, event.y)
    if region == "cell":
        column = table.identify_column(event.x)
        row = table.identify_row(event.y)

        item = table.item(table.focus())
        values = item['values']

        if column == '#1':  # Column 1 is Project ID
            fetch_biosamples(values[0])
        elif column in ('#3', '#4'):  # Column 3 is Title and Column 4 is Description
            if column == '#3':
                display_text_in_popup("Full Title", values[2])
            elif column == '#4':
                display_text_in_popup("Full Description", values[3])


root = tk.Tk()
root.title("Liver Cancer Metagenomics Search")
root.geometry("1000x800")  # Adjusted height to fit both frames
root.configure(bg='#121212')  # Set root background color to #121212

create_toolbar(root, open_intro, open_tool_interface, open_search, open_about)

# Styling
style = ttk.Style()
style.configure("TFrame", background="#2C2C2C")
style.configure("TLabel", background="#2C2C2C", foreground="#FFFFFF", font=("Helvetica", 12))

# Create a centered card layout for the search form
card_frame = ttk.Frame(root, padding=20, style="TFrame")
card_frame.pack(expand=True, pady=50)

# Create and style the search form
ttk.Label(card_frame, text="Population").grid(column=0, row=1, padx=10, pady=5, sticky="e")
population_var = tk.StringVar()
population_dropdown = ttk.Combobox(card_frame, textvariable=population_var, values=["Liver Cancer Patients", "Healthy Controls"])
population_dropdown.grid(column=1, row=1, padx=10, pady=10, sticky="w")

ttk.Label(card_frame, text="Intervention").grid(column=0, row=2, padx=10, pady=5, sticky="e")
intervention_var = tk.StringVar()
intervention_dropdown = ttk.Combobox(card_frame, textvariable=intervention_var, values=["Whole Genome Sequencing", "16S rRNA Sequencing"])
intervention_dropdown.grid(column=1, row=2, padx=10, pady=10, sticky="w")

ttk.Label(card_frame, text="Comparison").grid(column=0, row=3, padx=10, pady=5, sticky="e")
comparison_var = tk.StringVar()
comparison_dropdown = ttk.Combobox(card_frame, textvariable=comparison_var, values=["Stage I vs Stage IV", "Treated vs Untreated"])
comparison_dropdown.grid(column=1, row=3, padx=10, pady=10, sticky="w")

ttk.Label(card_frame, text="Outcome").grid(column=0, row=4, padx=10, pady=5, sticky="e")
outcome_var = tk.StringVar()
outcome_dropdown = ttk.Combobox(card_frame, textvariable=outcome_var, values=["Microbial Diversity", "Specific Pathogen Presence"])
outcome_dropdown.grid(column=1, row=4, padx=10, pady=10, sticky="w")

# Define hover effect functions for the search button
def on_enter_search(e):
    search_button['bg'] = '#D84315'

def on_leave_search(e):
    search_button['bg'] = '#E64A19'

# Create the search button with hover effects
search_button = tk.Button(card_frame, text="Search", font=("Helvetica", 15), bg="#E64A19", fg="white", borderwidth=0, relief=tk.FLAT, command=search_projects)
search_button.grid(column=0, row=5, columnspan=2, padx=20, pady=20)
search_button.bind("<Enter>", on_enter_search)
search_button.bind("<Leave>", on_leave_search)

# Create the content frame for displaying search results
content_frame = ttk.Frame(root, padding=10, style="TFrame")
content_frame.pack(fill=tk.BOTH, expand=True)


def copy_to_clipboard(event):
    """Copy the selected cell's content to the clipboard."""
    selected_item = table.selection()[0]  # Get the selected item
    selected_column = table.identify_column(event.x)  # Identify which column was clicked
    column_index = int(selected_column[1:]) - 1  # Get the index (e.g., #1 -> 0)
    
    item_values = table.item(selected_item, "values")
    if column_index < len(item_values):
        data = item_values[column_index]
        root.clipboard_clear()
        root.clipboard_append(data)
        show_message("Copied", f"Copied to clipboard: {data}")

# Styling
style = ttk.Style()
style.configure("TFrame", background="#2C2C2C")
style.configure("TLabel", background="#2C2C2C", foreground="#FFFFFF", font=("Helvetica", 12))

# Table style for background and alternating row colors
style.configure("Custom.Treeview", background="#3d3c3b", fieldbackground="#3d3c3b", foreground="white")
style.map("Custom.Treeview", background=[('selected', '#2b2b2a')])


# Create the table to display search results with the custom style
columns = ("Project ID", "Name", "Title", "Description", "Sample Count")
table = ttk.Treeview(content_frame, columns=columns, show='headings', style="Custom.Treeview")
for col in columns:
    table.heading(col, text=col)
    table.column(col, anchor="w")
table.grid(column=0, row=1, padx=10, pady=10, sticky='nsew')

# Enable right-click menu for copy functionality
table.bind("<Button-3>", copy_to_clipboard)  # Right-click event binding

table.bind("<ButtonRelease-1>", on_tree_click)



# Make the table expand with the window
content_frame.grid_rowconfigure(1, weight=1)
content_frame.grid_columnconfigure(0, weight=1)

create_footer(root)

# Run the tkinter main loop
# Create a progress bar in the main window
progress_var = tk.DoubleVar()
progress_bar = ttk.Progressbar(root, variable=progress_var, maximum=100)
progress_bar.pack(side="top", fill="x", padx=10, pady=10)

root.mainloop()