from libraries import *

def open_tool_interface():
    root.destroy()  # Close the current window
    import  advanced_search  # Replace with your actual module if it's in another file

def open_intro():
    root.destroy()  # Close the current window
    import intro  # Replace with your actual module if it's in another file

def open_about():
    root.destroy()  # Close the current window
    import about  # Replace with your actual module if it's in another file

def open_search():
    root.destroy()  # Close the current window
    import  quick_search  # Replace with your actual module if it's in another file
def learn_more():
    root.destroy()  # Close the current window
    import  learn_more  # Replace with your actual module if it's in another 

# Initialize the Tkinter application
root = tk.Tk()
root.title("About Pages")
root.geometry("1000x800")
root.configure(bg='#121212')

# Load the image and make it rounded
def make_rounded_image(image_path, size=(200, 200), radius=150):
    image = Image.open(image_path).resize(size, Image.Resampling.BICUBIC)
    mask = Image.new('L', size, 0)
    draw = ImageDraw.Draw(mask)
    draw.ellipse((0, 0) + size, fill=350)
    rounded_image = Image.new('RGBA', size)
    rounded_image.paste(image, (0, 0), mask=mask)
    return ImageTk.PhotoImage(rounded_image)

# Image path
image_paths = [
    "project\images\WhatsApp Image 2024-08-02 at 22.18.00_242e4a1d.jpg",
    "project\images\WhatsApp Image 2024-08-15 at 21.40.55_28a26ad4.jpg",
    "project\images\WhatsApp Image 2024-08-17 at 21.07.42_ff3291ff.jpg",
    "project\images\WhatsApp Image 2024-08-17 at 23.56.09_4767f1fc.jpg"
]
image_texts = [
    "Toka Nabil ",
    "Ahmed Gomaa",
    "Nour Elhoda Medhat",
    "Jana Amer"
]
# Load and create rounded images
images = [make_rounded_image(path) for path in image_paths]

create_toolbar(root, open_intro, open_tool_interface, open_search, open_about)

# Text Frame
text_frame = tk.Frame(root, bg='#2C2C2C')
text_frame.pack(side=tk.TOP, padx=20, pady=50)  # Add padding around the frame


def create_page1(parent, navigation):
    """Create the content for About Page 1."""
    frame = tk.Frame(parent, bg='#2C2C2C')
    label = tk.Label(frame, text="About the Team", bg='#2C2C2C', fg='white', font=('Helvetica', 26, 'bold'))
    label.pack(pady=10, padx=10)

    content_text = (
        "We are a team of computer scientists passionate about developing innovative tools that empower bioinformaticians in their research across various fields. Our expertise lies in creating solutions that simplify complex tasks, enabling users to efficiently search, analyze, and manage large-scale biological data."
    )
    content_label = tk.Label(frame, text=content_text, bg='#2C2C2C', fg='white', font=('Helvetica', 16),
                             wraplength=800, justify='left')
    content_label.pack(pady=10, padx=20, fill='both', expand=True)

    # Navigation buttons
    nav_frame = tk.Frame(frame, bg='#2C2C2C')
    nav_frame.pack(side=tk.BOTTOM, pady=20)

    if navigation.get('next'):
        next_button = tk.Button(nav_frame, text="Next", font=("Arial", 12), bg="#009688", fg="white", borderwidth=0,
                                command=navigation['next'])
        next_button.pack(side=tk.LEFT, padx=10)
    
    return frame

def create_page2(parent, navigation):
    """Create the content for About Page 2."""
    frame = tk.Frame(parent, bg='#2C2C2C')
    label = tk.Label(frame, text="Our Focus and Mission", bg='#2C2C2C', fg='white', font=('Helvetica', 26, 'bold'))
    label.pack(pady=10, padx=10)

    content_text = (
        "Our mission is to enhance the research process for bioinformaticians by providing user-friendly tools that integrate seamlessly with existing resources. While our work covers a broad spectrum of research topics, we are particularly focused on improving access to and management of metagenomic data, enabling scientists to make breakthroughs faster and with greater ease."
    )
    content_label = tk.Label(frame, text=content_text, bg='#2C2C2C', fg='white', font=('Helvetica', 16),
                             wraplength=800, justify='left')
    content_label.pack(pady=20, padx=20, fill='both', expand=True)

    # Navigation buttons
    nav_frame = tk.Frame(frame, bg='#2C2C2C')
    nav_frame.pack(side=tk.BOTTOM, pady=20)

    prev_button = tk.Button(nav_frame, text="Previous", font=("Arial", 12), bg="#E64A19", fg="white", borderwidth=0,
                            command=navigation['prev'])
    prev_button.pack(side=tk.LEFT, padx=10)
    
    if navigation.get('next'):
        next_button = tk.Button(nav_frame, text="Next", font=("Arial", 12), bg="#009688", fg="white", borderwidth=0,
                                command=navigation['next'])
        next_button.pack(side=tk.LEFT, padx=10)
    
    return frame
def create_page3(parent, navigation):
    """Create the content for About Page 3."""
    frame = tk.Frame(parent, bg='#2C2C2C')
    label = tk.Label(frame, text="Our Team Members", bg='#2C2C2C', fg='white', font=('Helvetica', 26, 'bold'))
    label.pack(pady=10, padx=10)

    content_text = (
        "Meet our dedicated team members who bring diverse skills and expertise to our projects. Each member is committed to advancing research and developing cutting-edge solutions in the field of bioinformatics."
    )
    content_label = tk.Label(frame, text=content_text, bg='#2C2C2C', fg='white', font=('Helvetica', 16),
                             wraplength=800, justify='left')
    content_label.pack(pady=20, padx=20, fill='both', expand=True)

    # Navigation buttons
    nav_frame = tk.Frame(frame, bg='#2C2C2C')
    nav_frame.pack(side=tk.BOTTOM, pady=20)

    prev_button = tk.Button(nav_frame, text="Previous", font=("Arial", 12), bg="#E64A19", fg="white", borderwidth=0,
                            command=navigation['prev'])
    prev_button.pack(side=tk.LEFT, padx=10)
    
    if navigation.get('next'):
        next_button = tk.Button(nav_frame, text="Next", font=("Arial", 12), bg="#009688", fg="white", borderwidth=0,
                                command=navigation['next'])
        next_button.pack(side=tk.LEFT, padx=10)
    
    return frame

def create_page4(parent, navigation):
    """Create the content for About Page 4."""
    frame = tk.Frame(parent, bg='#2C2C2C')
    label = tk.Label(frame, text="Contact Us", bg='#2C2C2C', fg='white', font=('Helvetica', 26, 'bold'))
    label.pack(pady=10, padx=10)

    content_text = (
        "For any inquiries or feedback, please reach out to us through the following channels:\n\n"
        "Email: j.amer2127@nu.edu.eg\n"
        "Phone: 01033284918\n"
        "Address: Nile University , Sheikh Zayed , Giza , Egypt "
    )
    content_label = tk.Label(frame, text=content_text, bg='#2C2C2C', fg='white', font=('Helvetica', 16),
                             wraplength=800, justify='left')
    content_label.pack(pady=20, padx=20, fill='both', expand=True)

    # Navigation buttons
    nav_frame = tk.Frame(frame, bg='#2C2C2C')
    nav_frame.pack(side=tk.BOTTOM, pady=20)

    prev_button = tk.Button(nav_frame, text="Previous", font=("Arial", 12), bg="#E64A19", fg="white", borderwidth=0,
                            command=navigation['prev'])
    prev_button.pack(side=tk.LEFT, padx=10)
    
    if navigation.get('next'):
        next_button = tk.Button(nav_frame, text="Next", font=("Arial", 12), bg="#009688", fg="white", borderwidth=0,
                                command=navigation['next'])
        next_button.pack(side=tk.LEFT, padx=10)
    
    return frame

def show_about_page(page_number):
    """Show a specific About page."""
    global current_page_frame
    if current_page_frame:
        current_page_frame.pack_forget()
    
    if page_number == 1:
        current_page_frame = create_page1(text_frame, {'next': lambda: show_about_page(2)})
    elif page_number == 2:
        current_page_frame = create_page2(text_frame, {'prev': lambda: show_about_page(1), 'next': lambda: show_about_page(3)})
    elif page_number == 3:
        current_page_frame = create_page3(text_frame, {'prev': lambda: show_about_page(2), 'next': lambda: show_about_page(4)})
    elif page_number == 4:
        current_page_frame = create_page4(text_frame, {'prev': lambda: show_about_page(3)})
    
    current_page_frame.pack(fill='both', expand=True)


current_page_frame = None
show_about_page(1)

# Image Row Frame
image_row_frame = tk.Frame(root, bg='#121212')
image_row_frame.pack(side=tk.TOP, fill=tk.X)

def create_image_row(parent, texts):
    """Creates a row with rounded images and text underneath."""
    frame = tk.Frame(parent, bg='#121212')
    
    for i in range(len(texts)):  # Adjusted to use the length of texts
        sub_frame = tk.Frame(frame, bg='#121212')
        image_label = tk.Label(sub_frame, image=images[i], bg='#121212')
        image_label.pack(side=tk.TOP, padx=10, pady=10)
        text_label = tk.Label(sub_frame, text=texts[i], bg='#121212', fg='white', font=('Helvetica', 12))
        text_label.pack(side=tk.TOP)
        sub_frame.pack(side=tk.LEFT, padx=10, pady=10)
    
    return frame

# Call create_image_row with the texts parameter
image_row = create_image_row(image_row_frame, image_texts)
image_row.pack(pady=10)

create_footer(root)

# Run the application
root.mainloop()