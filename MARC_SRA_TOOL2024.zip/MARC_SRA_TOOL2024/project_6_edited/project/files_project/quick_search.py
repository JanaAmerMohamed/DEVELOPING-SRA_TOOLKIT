from libraries import *

def open_tool_interface():
    root.destroy()  # Close the current window
    import  advanced_search  # Replace with your actual module if it's in another file

def open_about():
    root.destroy()  # Close the current window
    import  about  # Replace with your actual module if it's in another file

def open_search():
    root.destroy()  # Close the current window
    import  quick_search  # Replace with your actual module if it's in another file

def open_Intro():
    root.destroy()  # Close the current window
    import  intro  # Replace with your actual module if it's in another file

def learn_more():
    root.destroy()  # Close the current window
    import  learn_more  # Replace with your actual module if it's in another 

def download_sra():
    sra_id = entry.get()
    if not sra_id:
        messagebox.showwarning("Input Error", "Please enter an SRA ID")
        return
    
    # Ask user to select output directory
    output_directory = filedialog.askdirectory(title="Select Output Directory")
    if not output_directory:
        messagebox.showwarning("Output Directory", "Please select an output directory")
        return

    # Disable the button to prevent multiple submissions for the current download
    
    
    # Start the download in a separate thread
    thread = threading.Thread(target=download_fastq, args=(sra_id, output_directory))
    thread.start()
   

# Setting up the GUI
root = tk.Tk()
root.title("Marc")
root.geometry("1000x800")
root.configure(bg='#121212')  # Set the background to a very dark gray
create_toolbar(root, open_Intro, open_tool_interface, open_search, open_about)

def make_rounded_image(image_path, size=(200, 200), radius=100):
    image = Image.open(image_path).resize(size, Image.Resampling.LANCZOS)
    mask = Image.new('L', size, 0)
    draw = ImageDraw.Draw(mask)
    draw.ellipse((0, 0) + size, fill=255)
    rounded_image = Image.new('RGBA', size)
    rounded_image.paste(image, (0, 0), mask=mask)
    return ImageTk.PhotoImage(rounded_image)


#quick_search_label = tk.Label(root, text="Download Fastq File by Entering SRA ID", font=("Helvetica", 15,"bold"), bg="#121212", fg="white")
#quick_search_label.pack(pady=5)  # Further reduce the vertical padding

# Create a centered card layout for the search form with the new background color
card_frame = tk.Frame(root, bg="#2c2c2c", padx=30, pady=20)  # Reduced padding for card frame
card_frame.pack(expand=True, pady=5)  # Adjust padding for better placement

# Adding the label inside the card_frame
label = tk.Label(card_frame, text="Enter SRA ID:", font=("Helvetica", 12, "bold"), bg="#2c2c2c", fg="white", borderwidth=0)
label.pack(side="left", padx=(0, 10))

# Function to handle placeholder behavior
def on_entry_click(event):
    if entry.get() == "Download Fastq File by Entering SRA ID":
        entry.delete(0, "end")  # Remove placeholder text
        entry.config(fg="#2c2c2c")

def on_focusout(event):
    if entry.get() == "":
        entry.insert(0, "Download Fastq File by Entering SRA ID")
        entry.config(fg="#2c2c2c")

# Adding the entry field with increased width and height
entry = tk.Entry(card_frame, width=40, fg="grey", bg="white")
entry.insert(0, "Download Fastq File by Entering SRA ID")
entry.bind("<FocusIn>", on_entry_click)
entry.bind("<FocusOut>", on_focusout)
entry.pack(side="left", ipady=5)

# Adding the submit button with a yellow background and moving it slightly to the right
button = tk.Button(root, text="Download", font=("Helvetica", 14, "bold"), bg="#E64A19",fg="white", command=download_sra, width=20)
button.pack(pady=20, padx=0)  # Adding horizontal padding

create_footer(root)

root.mainloop()
